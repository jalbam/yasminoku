if (typeof(yasminokuAdsIncluded) === "undefined" || !yasminokuAdsIncluded)
{
	var yasminokuAdsIncluded = true;
	
	includeAds();
}


function includeAds()
{
	//TODO: include advertising system here.
}