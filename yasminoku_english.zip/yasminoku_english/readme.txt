  Yasminoku
 -----------> by Joan Alba Maldonado (100% DHTML).
              granvino@granvino.com

  Prohibited to publish, reproduce or modify without maintain author's name.

  Approximate date: 25 of July 2006 (fixes beyond 16 de August 2006).
  Dedicated to Yasmina Llaveria del Castillo.